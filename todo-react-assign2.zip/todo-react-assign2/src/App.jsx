import React from 'react';
import TodoApp from './components/TodoApp';

function App() {
  return <TodoApp />;
}

export default App;
